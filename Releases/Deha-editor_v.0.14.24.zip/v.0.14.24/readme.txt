=======================
Deha-editor User Manual
=======================

Introduction
------------
Deha-editor is a simple text editor which aims a sidebar-like usage with a mode-switch. With sidebar feature, you can put Deha-editor at the side of the windows. It will be always-on-top and other windows won't go under its window. Deha-editor will stay like a taskbar at the side of your monitor. You can use it like a stationary digital note taking.

Installation
------------
Deha-editor is only available for Microsoft Windows operating system. It is not necessary to install. Just expand the zip file and click to "deha-editor.exe" file.