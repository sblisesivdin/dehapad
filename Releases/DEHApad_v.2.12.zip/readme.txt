=======================
DEHApad Readme File
=======================

Introduction
------------
DEHApad is a simple text editor which aims a sidebar-like usage with a mode-switch. With sidebar feature, you can put DEHApad at the side of the windows. It will be always-on-top and other windows won't go under its window. DEHApad will stay like a taskbar at the side of your monitor. You can use it like a stationary digital note taking. It also has a text encryption/decryption feature.

Installation
------------
DEHApad is only available for Microsoft Windows operating system. It is not necessary to install. Just expand the zip file and click to "dehapad.exe" file.